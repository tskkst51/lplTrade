<?php
/**
 * E*TRADE PHP SDK
 *
 * @package    	PHP-SDK
 * @version		1.1
 * @copyright  	Copyright (c) 2012 E*TRADE FINANCIAL Corp.
 *
 */

class changeOptionOrderRequest extends changeOrderBase
{
	protected $stopLimitPrice;
	protected $priceType;
	protected $orderTerm;
}
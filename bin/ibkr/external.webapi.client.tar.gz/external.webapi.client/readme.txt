
mvn package
mvn dependency:build-classpath -Dmdep.outputFile=cp.txt

java \
   -cp $(cat cp.txt):target/webtradingapi.client-1.0.jar \
   com.interactivebrokers.webtradingapi.client.ConsumerStart \
   --resource etc/requests/marketdata.json \
   --consumer etc/consumer/consumer.json

Optionally add --login-mode paper for paper trading usernames. After the initial
run, you can extract the access token and live session token from the terminal
output and then rerun the command with --access-token and --live-session-token.
The live session token expires after one day, but the access token and access
token secret do not expire.  You can obtain a new live session token by using
the above command with --access-token and --access-secret, where the argument to
--access-secret is the base64-encoded *encrypted* access secret that is printed
to the terminal.

package com.interactivebrokers.webtradingapi.client;

import java.awt.*;
import java.io.IOException;
import java.math.BigInteger;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Scanner;

import org.apache.commons.cli.BasicParser;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.UnrecognizedOptionException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.interactivebrokers.webtradingapi.client.http.HttpConsumerClient;
import com.interactivebrokers.webtradingapi.client.oauth.OAuthMessenger;
import com.interactivebrokers.webtradingapi.client.oauth.SecuredRequest;

class ConsumerStart {

    private static final int EXIT_FAILED = 1;
    private static final Options options = new Options();
    private final static Logger logger = LoggerFactory.getLogger(ConsumerStart.class);
    private final static String defaultRealmName = "limited_poa";
    private final static String defaultLiveHostUrl = "https://www.interactivebrokers.com/tradingapi/v1/";
    private final static String defaultPaperHostUrl = "https://www.interactivebrokers.com/ptradingapi/v1/";

    public static void main(String[] args) throws Exception {

        initCmdLineOptions();

        CommandLineParser parser = new BasicParser();
        CommandLine cmd = null;
        try {
            cmd = parser.parse(options, args);
        } catch (UnrecognizedOptionException e) {
            logger.error("unrecognized option: {}", e.getMessage());
            printHelp();
        } catch (Exception e) {
            printHelp();
        }

        if (cmd == null || cmd.hasOption("h")) {
            printHelp();
            return;
        }

        final String file = cmd.getOptionValue("consumer", "");
        if (file.isEmpty()) {
            logger.error("consumer file required, see --consumer option");
            System.exit(EXIT_FAILED);
        }

        final String loginMode = cmd.getOptionValue("login-mode", "live");
        final String host = cmd.getOptionValue("host", "paper".equals(loginMode)
                ? defaultPaperHostUrl : defaultLiveHostUrl);
        final ThirdPartyConsumer consumer = new ThirdPartyConsumer(file);

        runFullAuthentication(cmd, host, consumer);
    }

    static Pair<String, byte[]> getAccessTokenAndLiveSessionToken(CommandLine cmd) {
        final String accessToken = cmd.getOptionValue("access-token");
        final String lstString = cmd.getOptionValue("live-session-token");

        if (accessToken == null || lstString == null) {
            return null;
        } else {
            return new ImmutablePair<>(accessToken, Base64.decodeBase64(lstString));
        }
    }

    static Pair<String, String> getAccessTokenAndAccessSecret(CommandLine cmd) {
        final String accessToken = cmd.getOptionValue("access-token");
        final String accessSecret = cmd.getOptionValue("access-secret");

        if (accessToken == null || accessSecret == null) {
            return null;
        } else {
            return new ImmutablePair<>(accessToken, accessSecret);
        }
    }

    private static void runFullAuthentication(CommandLine cmd, String host, ThirdPartyConsumer consumer)
            throws Exception {

        final String resource = cmd.getOptionValue("resource");

        if (resource == null || resource.isEmpty()) {
            logger.error("specify a protected resource with --resource");
            return;
        }

        final SecuredRequest protectedRequest = SecuredRequest.load(resource);

        final HttpConsumerClient client = new HttpConsumerClient(consumer, host);
        client.setDebugHttp(cmd.hasOption("print-http"));

        // LIVE SESSION TOKEN MODE
        final Pair<String, byte[]> accessLst = getAccessTokenAndLiveSessionToken(cmd);
        if (accessLst != null) {
            client.sendProtectedResourceRequest(accessLst.getKey(), accessLst.getValue(), protectedRequest);
            return;
        }

        // ACCESS TOKEN MODE
        final Pair<String, String> tokenAndSecret = getAccessTokenAndAccessSecret(cmd);
        if (tokenAndSecret != null) {
            obtainLiveSessionTokenAndExecuteRequest(client, tokenAndSecret.getKey(), tokenAndSecret.getValue(),
                    protectedRequest);
            return;
        }

        // FULL AUTHENTICATION MODE

        final String requestToken = client.sendConsumerRequestToken();
        if (requestToken == null || requestToken.isEmpty()) {
            logger.error("Invalid request token, aborting authentication");
            return;
        }

        obtainRequestToken(requestToken);
        System.out.println("\n\nInput the oauth_verifier from the authorize callback url (16-digit hex): ");
        Scanner scanner = new Scanner(System.in);
        String verifier;

        while (true) {
            verifier = scanner.nextLine();
            try {
                //noinspection ResultOfMethodCallIgnored
                new BigInteger(verifier, 16);
                scanner.close();
                break;
            } catch (NumberFormatException e) {
                System.out.println(verifier + " does not seem to be a hex value, try again: ");
            }
        }

        final Pair<String, String> vals = OAuthMessenger
                .obtainAccessTokenFromRequestToken(client, requestToken, verifier);
        logger.debug("----------------------------------------------------------------------------------");

        if (vals == null) {
            logger.error("Aborting full run, null token/secret");
            return;
        }

        final String accessToken = vals.getKey();
        final String encryptedSecret = vals.getValue();

        logger.info("Sleeping 0.5 seconds to allow access token propagation");
        Thread.sleep(500);

        obtainLiveSessionTokenAndExecuteRequest(client, accessToken, encryptedSecret, protectedRequest);
    }

    private static void obtainLiveSessionTokenAndExecuteRequest(HttpConsumerClient client, String accessToken,
            String encryptedSecret, SecuredRequest protectedRequest) throws Exception {
        final byte[] lst = OAuthMessenger.getLiveSessionToken(client, accessToken, encryptedSecret);
        logger.debug("----------------------------------------------------------------------------------");

        if (lst == null)
            logger.error("aborting full run, null live session token");
        else {
            logger.info("Sleeping 0.5 seconds to allow live session token propagation");
            Thread.sleep(500);
            client.sendProtectedResourceRequest(accessToken, lst, protectedRequest);
        }
    }

    private static void obtainRequestToken(String token) {
        final String login = "http://www.interactivebrokers.com/authorize?oauth_token=" + token;

        try {
            if (!Desktop.isDesktopSupported()) {
                Runtime.getRuntime().exec("xdg-open " + login);
            } else {
                Desktop.getDesktop().browse(new URI(login));
            }

            logger.info("opened {}", login);
        } catch (IOException | URISyntaxException e) {
            System.out.println("\nVisit " + login + " to continue\n");
        }
    }

    @SuppressWarnings("static-access")
    private static void initCmdLineOptions() {
        options.addOption("h", "help", false, "print this message");

        // use in combination --access-token + --access-secret to obtain a live session token and then visit a resource
        options.addOption(null, "access-token", true, "access token");
        options.addOption(null, "access-secret", true, "base64-encoded access secret");

        // use in combination --access-token + --live-session-token to visit a resource
        options.addOption(null, "live-session-token", true, "base64-encoded live session token");

        options.addOption(null, "consumer", true, "path to consumer.json file");
        options.addOption(null, "resource", true, "description of the http request to be made in json format");
        options.addOption(null, "print-http", false, "print outgoing http request to the stdout");
        options.addOption(null, "login-mode", true, "use --login-mode paper to specify a paper-trading login");
    }

    private static void printHelp() {
        System.out.println(
                "\nNOTE: for PAPER trading (vs. real trading) user names, you need to specify \n"
                        + "   --login-mode paper\n\n"
                        + "Run in one of three modes: \n"
                        + "  1) no command line arguments given (FULL AUTHENTICATION MODE)\n"
                        + "     * request token is requested\n"
                        + "     * authorize url is opened in browser\n"
                        + "     * verification token is entered in terminal\n"
                        + "     * access token and secret are obtained\n"
                        + "     * live session token is obtained\n"
                        + "     * protected resource is visited\n"
                        + "  2) --access-token and --access-secret (ACCESS SECRET MODE)\n"
                        + "     Use the access token and base64-encoded encrypted access secret that are printed from full authentication mode\n"
                        + "     * live session token is obtained\n"
                        + "     * protected resource is visited\n"
                        + "  3) --access-token and --live-session-token\n"
                        + "     Use the access token and base64-encoded live session token that are printed from full authentication mode or access secret mode\n"
                        + "     * protected resource is visited"
        );
        HelpFormatter help = new HelpFormatter();
        help.printHelp("java -jar RunCli or java -cp .jar " + ConsumerStart.class.getSimpleName(), options);
        System.exit(EXIT_FAILED);
    }

}
